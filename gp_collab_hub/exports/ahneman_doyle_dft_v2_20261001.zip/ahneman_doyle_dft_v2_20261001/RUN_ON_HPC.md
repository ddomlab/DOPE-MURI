# ahneman_doyle_dft_v2_20261001

Built by the DOPE-MURI hub on 2026-10-01 for dataset `ahneman_doyle_dft`.
72 jobs: 18 feature sections x 4 evaluation methods.

Upload, unzip, and from inside `ahneman_doyle_dft_v2_20261001/`:

    bash hazel/setup_environment.sh            # once, on a login node
    bash hazel/slurm/GP_preflight_GPU_arg.sh   # GPU visibility + float64 Cholesky
    bash hazel/slurm/GP_GPU_arg.sh             # the 72 jobs, collection chained behind

Settings already written into the scripts:

    run tag      ahneman_doyle_dft_v2_20261001          -> runs/ahneman_doyle_dft_v2_20261001/
    conda env    /usr/local/usrapps/ddomlab/kagoble/gp_collab_hazel_py312
    GPU          gpu:l40:1
    walltime     00:20:00 per task
    memory       16G, 4 CPUs per task
    pilot        0   (1 = 10 epochs into runs/ahneman_doyle_dft_v2_20261001_pilot, to size walltime)

Bring back the whole `runs/ahneman_doyle_dft_v2_20261001/` folder. In the hub:

    python -m gpc --runs <that folder> --bundle datasets/ahneman_doyle_dft/inputs report

which writes `results/ahneman_doyle_dft_<date>/` with the figures and tables.

`inputs/ligand_features.csv` holds only the ligands this screen uses; the full
Kraken reference stays in the hub, where the figures are drawn.
