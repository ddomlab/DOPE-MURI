"""Run one (feature section, evaluation method) pair through GP_collab's CV.

The pipeline is this bundle's per-fold one-hot encoder followed by GP_collab's
GPytorchMAP regressor, cross-validated by GP_collab's `cross_validate`. Each job
is one model/method pair; its folds run inside that job.

Nothing here knows which dataset it is running. The group column, the target and
the condition fields all come from the bundle's config.json.
"""
from __future__ import annotations

import platform
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

from .config import bundle_group, bundle_target, write_json
from .data import load_bundle
from .features import _preprocessor, apply_feature_overrides, feature_frame
from .runlog import append_run_log
from .splits import PrecomputedSplits, make_folds
from .vendor.kernel_mix import GPytorchMAPsklearnRegressor
from .vendor.scoring import cross_validate_regressor, process_scores

MODEL_TYPE = "GPytorchMAP"  # GP_collab keys parallel/UQ behaviour off "gp" in this


def _group_columns(group: str):
    """The group block: its one-hot columns, plus any numeric column."""
    def select(columns):
        return [c for c in columns
                if c.startswith("num__") or c.startswith(f"cat__{group}_")]
    return select


def _condition_columns(group: str):
    def select(columns):
        return [c for c in columns
                if c.startswith("cat__") and not c.startswith(f"cat__{group}_")]
    return select


def _field_group(field):
    def select(columns):
        return [c for c in columns if c.startswith(f"cat__{field}_")]
    return select


def feature_groups(grouping: str, prepared: dict) -> dict:
    """Map encoded columns onto GP_collab kernel groups.

    For an RBF kernel on disjoint column sets, product mixing is identical to one
    RBF whose lengthscales are shared within each group, so this choice only sets
    how many lengthscales the kernel has. "all" with ard=False is a single
    isotropic RBF over every encoded column.

    `ligand_conditions` and `catalyst_reagents` are the two names the original
    projects gave `group_conditions`; they are accepted so an old run config
    still runs here and produces the same kernel.
    """
    group = bundle_group(prepared)
    if grouping == "all":
        return {"fp_all": "__all__"}
    if grouping in ("group_conditions", "ligand_conditions", "catalyst_reagents"):
        return {"fp_group": _group_columns(group),
                "fp_conditions": _condition_columns(group)}
    if grouping == "per_field":
        groups = {"fp_group": _group_columns(group)}
        for field in prepared["data"]["common_categorical"]:
            groups[f"fp_{field}"] = _field_group(field)
        return groups
    raise ValueError(f"Unknown grouping {grouping!r}")


def effective_config(cfg: dict, model: str) -> dict:
    """`cfg` with run.model_overrides[model] folded into the gp block.

    Precedence, lowest to highest: the run config's gp block, then this model's
    override, then the CLI --epochs flag (cli.py already wrote that into
    cfg["gp"]). The "walltime" key is scheduling metadata read by the submit
    scripts, not a GP parameter, so it is carried in meta.json but never handed
    to the regressor.
    """
    override = dict(cfg.get("run", {}).get("model_overrides", {}).get(model, {}))
    if not override:
        return cfg
    override.pop("walltime", None)
    out = dict(cfg)
    out["gp"] = {**cfg["gp"], **override}
    return out


def build_regressor(cfg: dict, prepared: dict, seed: int) -> GPytorchMAPsklearnRegressor:
    gp = cfg["gp"]
    return GPytorchMAPsklearnRegressor(
        feat_group=feature_groups(gp["grouping"], prepared),
        kernel_type={"fp": gp["kernel"], "count": gp["kernel"]},
        kernel_mixing_method=gp["mixing_method"],
        ard=gp["ard"],
        dtype=gp["dtype"],
        noise=gp["noise"],
        noise_floor=gp["noise_floor"],
        outputscale=gp["outputscale"],
        train_jitter=gp["train_jitter"],
        predict_jitter=gp["predict_jitter"],
        restarts=gp["restarts"],
        n_epoch=gp["n_epochs"],
        lr=gp["learning_rate"],
        prior=gp["prior"],
        normalize_y=gp["normalize_y"],
        random_state=seed,
        progbar=False,
        use_cuda=gp["use_cuda"],
    )


def run_task(bundle, runs, model: str, method: str, cfg: dict) -> Path:
    import torch

    cfg = effective_config(cfg, model)
    reactions, ligands, reference, prepared = load_bundle(bundle)
    # run.feature_columns, if the run config set it, redefines which descriptors
    # selected_2/selected_5/pc_top feed. Applied here so training, the encoded
    # width in meta.json and the review path all see the same definition.
    prepared = apply_feature_overrides(prepared, cfg)
    seed = cfg["run"]["seed"]
    target = bundle_target(prepared)
    group = bundle_group(prepared)

    X = feature_frame(reactions, ligands, model, prepared, reference)
    y = reactions[target].to_numpy(dtype=float)

    folds, references = make_folds(reactions, method, seed, cfg["run"]["stratify"], group)
    fold_of_row = np.empty(len(reactions), dtype=np.int64)
    for i, (_, test) in enumerate(folds):
        fold_of_row[test] = i

    preprocessor = _preprocessor(X, model, prepared, reference)
    regressor = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("regressor", build_regressor(cfg, prepared, seed)),
    ])
    regressor.set_output(transform="pandas")

    use_gpu = cfg["gp"]["use_cuda"] and torch.cuda.is_available()
    torch.set_num_threads(int(cfg["run"]["threads"]))

    start = time.time()
    scores, predictions = cross_validate_regressor(
        regressor,
        MODEL_TYPE,
        X, y,
        PrecomputedSplits(folds),
        UQ=True,
        return_ls=True,
        n_jobs=1 if use_gpu else -1,
    )
    scores = process_scores({seed: dict(scores)})
    scores["run_time_sec"] = round(time.time() - start, 3)

    out = Path(runs) / f"{model}__{method}"
    out.mkdir(parents=True, exist_ok=True)

    # The group column is written under the fixed name "group_value" AND under
    # its own name, so downstream code can read it without knowing the dataset
    # while a human reading the CSV still sees "ligand" or "catalyst".
    pd.DataFrame({
        "row_id": reactions["row_id"],
        "group_value": reactions[group],
        group: reactions[group],
        "fold": fold_of_row,
        "reference_group": [references[f] for f in fold_of_row],
        "y_true": y,
        "y_pred": predictions["y_pred"],
        "y_std": predictions["y_std"],
    }).to_csv(out / "predictions.csv", index=False)

    write_json(out / "scores.json", scores)
    write_json(out / "meta.json", {
        "model": model, "method": method, "seed": seed,
        "dataset": prepared.get("dataset"), "group": group, "target": target,
        "stratify": cfg["run"]["stratify"], "n_folds": len(folds),
        "n_rows": len(reactions), "n_features": int(X.shape[1]), "config": cfg,
        "device": "cuda" if use_gpu else "cpu",
        "versions": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
        },
    })
    append_run_log(runs, model, method, cfg, {"n_features": int(X.shape[1])})
    print(f"{model}/{method}: r2={scores.get('r2_avg'):.3f} "
          f"rmse={scores.get('rmse_avg'):.3f} -> {out}")
    return out
