"""Integrity-checked collection, uncertainty metrics, and local review plots."""
from __future__ import annotations

from pathlib import Path
import zipfile
import numpy as np
import pandas as pd
from scipy.stats import norm, kendalltau, spearmanr
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

from .config import TARGET, read_json, write_json, file_hash, object_hash
from .data import verify_bundle
from .splits import load_split


def _finite_or_none(value):
    return float(value) if np.isfinite(value) else None


def regression_metrics(y, mean, std) -> dict:
    y, mean, std = (np.asarray(v, dtype=float).reshape(-1) for v in (y, mean, std))
    if not (len(y) == len(mean) == len(std)) or not len(y):
        raise ValueError("Metric arrays must have equal nonzero lengths")
    if not np.isfinite(np.r_[y, mean, std]).all() or np.any(std <= 0):
        raise ValueError("Predictions/uncertainties must be finite with positive predictive standard deviation")
    z = (y - mean) / std
    pit = norm.cdf(z)
    qs = np.linspace(0, 1, 101)
    pit_cdf = np.array([(pit <= q).mean() for q in qs])
    out = {"n_test": len(y), "r2": float(r2_score(y, mean)) if len(y) > 1 and np.var(y) > 0 else None,
           "rmse": float(np.sqrt(mean_squared_error(y, mean))), "mae": float(mean_absolute_error(y, mean)),
           "kendall_tau": _finite_or_none(kendalltau(y, mean).statistic) if len(y) > 1 else None,
           "predictive_nll": float(np.mean(0.5 * z**2 + np.log(std) + 0.5 * np.log(2 * np.pi))),
           "mean_predictive_std": float(std.mean()),
           "pit_cdf_mae": float(np.mean(np.abs(pit_cdf - qs))),
           "abs_residual_std_spearman": _finite_or_none(spearmanr(np.abs(y - mean), std).statistic)
                if len(y) > 1 and np.std(std) > 0 and np.std(np.abs(y-mean)) > 0 else None}
    for coverage in (0.50, 0.80, 0.95):
        q = norm.ppf((1 + coverage) / 2)
        out[f"coverage_{int(100*coverage)}"] = float((np.abs(z) <= q).mean())
        out[f"width_{int(100*coverage)}"] = float((2 * q * std).mean())
    return out


def task_statuses(bundle, runs) -> pd.DataFrame:
    """Read-only status inspection, including missing jobs; no result aggregation."""
    bundle, runs = Path(bundle), Path(runs)
    verify_bundle(bundle)
    tasks = pd.read_csv(bundle / "tasks.csv", keep_default_na=False)
    rows = []
    for task in tasks.to_dict("records"):
        path = runs / "tasks" / f"task_{task['task_id']:04d}" / "status.json"
        meta = read_json(path) if path.exists() else {"state": "missing"}
        rows.append({**task, "state": meta["state"], "error": meta.get("error", "")})
    return pd.DataFrame(rows)


def collect_results(bundle, runs, allow_partial=False):
    bundle, runs = Path(bundle), Path(runs)
    manifest = verify_bundle(bundle)
    run = read_json(runs / "run.json")
    if run["bundle_id"] != manifest["bundle_id"]:
        raise ValueError("Results and input bundle do not match")
    if object_hash({k: v for k, v in run.items() if k not in ("run_id", "n_tasks")}) != run["run_id"]:
        raise ValueError("Run metadata changed")
    tasks = pd.read_csv(bundle / "tasks.csv", keep_default_na=False)
    reactions = pd.read_csv(bundle / "reactions.csv", keep_default_na=False)
    status_table = task_statuses(bundle, runs)
    missing = status_table.loc[status_table.state != "completed", "task_id"].astype(int).tolist()
    if missing and not allow_partial:
        raise RuntimeError(f"{len(missing)} tasks incomplete; first IDs: {missing[:20]}. "
                           "Run status, finish/retry these tasks, or use --allow-partial for a labeled pilot report.")
    predictions, metric_rows = [], []
    for task in tasks.to_dict("records"):
        if task["task_id"] in missing:
            continue
        directory = runs / "tasks" / f"task_{task['task_id']:04d}"
        status = read_json(directory / "status.json")
        if status["run_id"] != run["run_id"] or status["task"] != task:
            raise ValueError(f"Task identity mismatch: {task['task_id']}")
        for name, digest in status["output_hashes"].items():
            if file_hash(directory / name) != digest:
                raise ValueError(f"Corrupt task output: {directory / name}")
        pred = pd.read_csv(directory / "predictions.csv", keep_default_na=False)
        _, _, te = load_split(bundle, task["split_id"])
        expected = reactions.iloc[te]
        if (len(pred) != len(te) or pred.row_id.duplicated().any()
                or pred.row_id.tolist() != expected.row_id.tolist()
                or pred.ligand.tolist() != expected.ligand.tolist()
                or not np.array_equal(pred.test_index.to_numpy(), te)
                or not np.allclose(pred.y_true, expected[TARGET], atol=1e-10, rtol=1e-12)):
            raise ValueError(f"Prediction rows/targets do not match split: {task['task_id']}")
        for key in ("task_id", "model", "split_id", "method", "reference_group", "repeat", "fold"):
            if not pred[key].eq(task[key]).all():
                raise ValueError(f"Prediction metadata changed: {key}")
        scores = regression_metrics(pred.y_true, pred.y_pred, pred.predictive_std)
        pred["pit"] = norm.cdf((pred.y_true - pred.y_pred) / pred.predictive_std)
        for coverage in (50, 80, 95):
            q = norm.ppf((1 + coverage / 100) / 2)
            pred[f"lower_{coverage}"] = pred.y_pred - q * pred.predictive_std
            pred[f"upper_{coverage}"] = pred.y_pred + q * pred.predictive_std
        predictions.append(pred)
        fit = read_json(directory / "fit.json")
        metric_rows.append({**task, **scores, "n_features": fit["n_features"],
                            "fit_seconds": fit["fit_seconds"],
                            "selected_stop_reason": fit["restart_summaries"][fit["selected_restart"]]["stop_reason"]})
    if not predictions:
        raise RuntimeError("No completed tasks to collect")
    pred = pd.concat(predictions, ignore_index=True)
    metrics = pd.DataFrame(metric_rows)
    score_names = [k for k in regression_metrics([0., 1.], [0., 1.], [1., 1.]) if k != "n_test"]
    summary = []
    for (model, method), part in metrics.groupby(["model", "method"], sort=False):
        expected_count = int(((tasks.model == model) & (tasks.method == method)).sum())
        common = {"model": model, "method": method, "completed_fits": len(part),
                  "expected_fits": expected_count, "complete_method": len(part) == expected_count,
                  "run_complete": not missing}
        average = {k: _finite_or_none(pd.to_numeric(part[k], errors="coerce").mean()) for k in score_names}
        summary.append({**common, "aggregation": "mean_split_metrics", **average})
        if method in ("lolo", "kfold", "holdout"):
            p = pred.loc[(pred.model == model) & (pred.method == method)]
            if p.row_id.duplicated().any():
                raise ValueError("Unexpected repeated rows in pooled out-of-fold predictions")
            summary.append({**common, "aggregation": "pooled_predictions",
                            **regression_metrics(p.y_true, p.y_pred, p.predictive_std)})
    # Match the earlier group-oriented interface without using seeds as dictionary keys.
    iid_group_rows = []
    for (model, ref), part in metrics[metrics.method == "iid_matched"].groupby(["model", "reference_group"]):
        iid_group_rows.append({"model": model, "reference_group": ref, "completed_repeats": len(part),
                               **{k: _finite_or_none(pd.to_numeric(part[k], errors="coerce").mean()) for k in score_names}})
    tables = {"predictions": pred, "metrics_by_split": metrics, "summary": pd.DataFrame(summary),
              "iid_by_reference_group": pd.DataFrame(iid_group_rows), "task_status": status_table}
    dest = runs / "collected"
    dest.mkdir(exist_ok=True)
    for name, frame in tables.items():
        temp = dest / (name + ".tmp.csv")
        frame.to_csv(temp, index=False)
        temp.replace(dest / (name + ".csv"))
    write_json(dest / "collection.json", {"run_id": run["run_id"], "bundle_id": manifest["bundle_id"],
               "complete": not missing, "expected_tasks": len(tasks), "completed_tasks": len(metric_rows),
               "incomplete_task_ids": missing, "iid_pooling": "No pooled IID score; average split metrics because repeats overlap.",
               "output_hashes": {name + ".csv": file_hash(dest / (name + ".csv")) for name in tables}})
    return tables


def load_results(runs):
    directory = Path(runs) / "collected"
    info = read_json(directory / "collection.json")
    for name, digest in info["output_hashes"].items():
        if file_hash(directory / name) != digest:
            raise ValueError(f"Collected result changed: {name}")
    tables = {}
    for name in ("predictions", "metrics_by_split", "summary", "iid_by_reference_group", "task_status"):
        try:
            tables[name] = pd.read_csv(directory / f"{name}.csv", keep_default_na=False)
        except pd.errors.EmptyDataError:
            tables[name] = pd.DataFrame()
    return tables, info


def grouped_predictions(predictions, model, method="iid_matched"):
    """Return {group: {y_pred: [array per repeat], y_std: [...], test_idx: [...]}}."""
    p = predictions.loc[(predictions.model == model) & (predictions.method == method)]
    out = {}
    for group, part in p.groupby("reference_group", sort=False):
        folds = [v for _, v in part.groupby("split_id", sort=True)]
        out[group] = {"y_pred": [v.y_pred.to_numpy() for v in folds],
                      "y_std": [v.predictive_std.to_numpy() for v in folds],
                      "test_idx": [v.test_index.to_numpy() for v in folds],
                      "y_true": [v.y_true.to_numpy() for v in folds]}
    return out


def plot_parity(predictions, model, method="lolo", reference_group=None, split_id=None):
    import matplotlib.pyplot as plt
    p = predictions.loc[(predictions.model == model) & (predictions.method == method)].copy()
    if reference_group is not None:
        p = p[p.reference_group == reference_group]
    if split_id is not None:
        p = p[p.split_id == split_id]
    if p.empty:
        raise ValueError("No predictions match the selected model/method/group/split")
    fig, ax = plt.subplots(figsize=(5, 4.5), constrained_layout=True)
    for ligand, group in p.groupby("ligand"):
        ax.scatter(group.y_true, group.y_pred, s=14, alpha=0.65, label=ligand)
    lo, hi = min(0, p.y_pred.min()), max(100, p.y_pred.max())
    ax.plot([lo, hi], [lo, hi], color="black", linestyle="--", linewidth=1)
    ax.set(xlabel="Observed UV-area yield (%)", ylabel="Predicted UV-area yield (%)", title=f"{model} | {method}")
    ax.legend(fontsize=7, frameon=False, ncol=2)
    return fig


def plot_lolo_comparison(metrics, metric="rmse"):
    import matplotlib.pyplot as plt
    part = metrics[metrics.method == "lolo"]
    if part.empty:
        raise ValueError("No LOLO results available")
    table = part.pivot(index="reference_group", columns="model", values=metric)
    ax = table.plot.bar(figsize=(10, 4), width=0.85)
    ax.set(xlabel="Held-out ligand", ylabel=metric.upper())
    ax.tick_params(axis="x", rotation=35)
    ax.legend(title="Model", fontsize=8)
    ax.figure.tight_layout()
    return ax.figure


def plot_calibration(predictions, method="lolo"):
    """For IID, averages per-split empirical PIT CDFs; no IID independence claim."""
    import matplotlib.pyplot as plt
    part = predictions[predictions.method == method]
    if part.empty:
        raise ValueError("No predictions for this method")
    grid = np.linspace(0, 1, 101)
    fig, ax = plt.subplots(figsize=(5, 4.5), constrained_layout=True)
    for model, group in part.groupby("model"):
        curves = []
        groups = [p for _, p in group.groupby("split_id")] if method == "iid_matched" else [group]
        for p in groups:
            pit = norm.cdf((p.y_true - p.y_pred) / p.predictive_std)
            curves.append(np.array([(pit <= q).mean() for q in grid]))
        ax.plot(grid, np.mean(curves, axis=0), label=model)
    ax.plot(grid, grid, "k--", linewidth=1)
    ax.set(xlabel="Nominal cumulative probability", ylabel="Observed PIT CDF", title=method, xlim=(0, 1), ylim=(0, 1))
    ax.legend(fontsize=8, frameon=False)
    return fig


def export_result_archive(runs, destination, include_checkpoints=False):
    runs, dst = Path(runs).resolve(), Path(destination).resolve()
    if dst.exists():
        raise FileExistsError(dst)
    load_results(runs)  # Require a collected, hash-verified report.
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_suffix(".tmp.zip")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(runs.rglob("*")):
            if not p.is_file() or p == dst or p == tmp or p.name.startswith("."):
                continue
            if p.name in ("model.pt", "preprocessor.joblib") and not include_checkpoints:
                continue
            z.write(p, str(Path(runs.name) / p.relative_to(runs)))
    tmp.replace(dst)
    return dst
