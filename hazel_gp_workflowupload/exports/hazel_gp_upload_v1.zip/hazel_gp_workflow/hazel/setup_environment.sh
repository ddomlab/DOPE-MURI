#!/bin/bash
# Run on a Hazel login node to install a NEW environment into your usrapps space.
set -euo pipefail
: "${HAZEL_ENV_PREFIX:?Set HAZEL_ENV_PREFIX=/usr/local/usrapps/GROUP/USER/hazel_gp_py312}"
: "${HAZEL_CACHE_DIR:?Set HAZEL_CACHE_DIR=/share/GROUP/USER/conda_cache}"
if [[ -e "$HAZEL_ENV_PREFIX" ]]; then
    echo "Environment destination already exists. Activate it, or choose a new environment path." >&2
    exit 1
fi
module load conda
eval "$(conda shell.bash hook)"
mkdir -p "$HAZEL_CACHE_DIR"
export CONDA_PKGS_DIRS="$HAZEL_CACHE_DIR/conda_pkgs"
export PIP_CACHE_DIR="$HAZEL_CACHE_DIR/pip"
conda create --prefix "$HAZEL_ENV_PREFIX" python=3.12 pip --yes
conda activate "$HAZEL_ENV_PREFIX"
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu126
python -m pip install -r requirements-cluster.txt
python -m pip check
python -m pip freeze > "$HAZEL_CACHE_DIR/hazel_gp_environment_freeze.txt"
echo "Environment installed. Submit the allocated GPU preflight before training."
