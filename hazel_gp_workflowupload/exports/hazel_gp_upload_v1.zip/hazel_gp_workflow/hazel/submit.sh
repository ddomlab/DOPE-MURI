#!/bin/bash
# Usage: bash hazel/submit.sh gpu [additional sbatch options]
set -euo pipefail
: "${HAZEL_ENV_PREFIX:?Set the installed environment path}"
mode="${1:-gpu}"
if [[ $# -gt 0 ]]; then shift; fi
if [[ "$mode" != gpu && "$mode" != cpu ]]; then echo "Mode must be gpu or cpu" >&2; exit 1; fi
export HAZEL_BUNDLE="${HAZEL_BUNDLE:-inputs}"
export HAZEL_RUNS="${HAZEL_RUNS:-runs/experiment_v1}"
export PYTHONNOUSERSITE=1
mkdir -p logs exports
count=$("$HAZEL_ENV_PREFIX/bin/python" -m hazel_gp tasks --bundle "$HAZEL_BUNDLE" --count)
concurrency="${HAZEL_CONCURRENCY:-4}"
array="${HAZEL_ARRAY:-0-$((count - 1))%$concurrency}"
job=$(sbatch --parsable --array="$array" "$@" "hazel/${mode}_array.sbatch")
job="${job%%;*}"
echo "Submitted training array $job ($array)."
if [[ "${HAZEL_COLLECT:-1}" == 1 ]]; then
    # The collector runs only if every submitted task succeeds, then checks the full task registry.
    sbatch --dependency="afterok:$job" hazel/collect.sbatch
else
    echo "Automatic collection disabled (pilot or selected tasks)."
fi
